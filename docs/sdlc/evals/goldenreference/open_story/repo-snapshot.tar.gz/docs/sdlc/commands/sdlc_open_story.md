Please open the user story for development: $ARGUMENTS.

This command uses sub-agent orchestration: self-contained steps are delegated to separate sub-agents with fresh context windows, using cheaper models (Sonnet/Haiku) where appropriate. Interactive steps (git operations, user questions) remain with the orchestrator.

Sub-agent orchestration is the default execution strategy for this command.

## Execution Metrics

At the very start of this command, before any other work:

1. **Record start time.** Run `date +%s` and store the result as `{START_EPOCH}`.
2. **Initialise interaction counter.** Set `{INTERACTION_COUNT}` to 0. Each time you pause execution to ask the user a question or wait for user input (e.g. uncommitted changes warning, branch choice, story confirmation), increment `{INTERACTION_COUNT}` by 1 before resuming.

These values are used in the report step to produce the Command Metrics subsection.

## Steps

Follow these steps:

1. **Check for uncommitted changes.** Run `git status` to detect any uncommitted changes (staged, unstaged, or untracked files). If changes are present, warn the user listing the changes and ask if they want to proceed anyway. If the user says no, stop. If the user says yes, continue to step 2. DO NOT MAKE ASSUMPTIONS and DO NOT DELETE DATA.

2. **Handle current branch.** Run `git branch --show-current` to determine the current branch.

   - **If on `main`:** Fetch and pull the latest changes from remote. If the pull fails or there are conflicts, inform the user and ask how to proceed. DO NOT MAKE ASSUMPTIONS.
   - **If NOT on `main`:** Inform the user of the current branch name and ask whether they want to proceed on the current branch or switch to `main`.
     - If the user chooses to **proceed on the current branch**: continue to step 3. Note that branch creation in step 5 must be skipped.
     - If the user chooses to **switch to `main`**: switch to `main`, then fetch and pull the latest changes from remote. If the pull fails or there are conflicts, inform the user and ask how to proceed. DO NOT MAKE ASSUMPTIONS.

3. **Resolve the user story argument.** If `$ARGUMENTS` is empty or not provided, identify the **Next User Story** as defined in @docs/guidelines/guidelines-userstories.md. Inform the user which story was auto-selected. If no actionable story exists, inform the user and stop.

4. **Locate the user story.** Match the argument against the user story files by number or partial name. If no match is found, ask the user which user story to open. Validate the **preconditions for Opening** as defined in @docs/guidelines/guidelines-userstories.md. If they are not met, inform the user and stop.

5. **Create a feature branch (conditional).** Skip this step if the user chose to proceed on their current non-main branch in step 2. Otherwise, using the resolved user story reference:
   1. The new branch should live under the "feature" folder.
   2. The new branch should start with the ticket number or reference of the user story.

6. **Open the user story (sub-agent).** Spawn a sub-agent to perform the **Opening** operation.

   ```
   Agent(
     description: "Open user story",
     model: "haiku",
     prompt: "<constructed prompt>"
   )
   ```

   **Sub-agent prompt:**
   ```
   You are performing a file-management operation to open a user story for development.

   ## Task

   Perform the Opening operation as defined in the user story guidelines.

   Read the guidelines at: docs/guidelines/guidelines-userstories.md

   Then apply the Opening operation to the user story file at:
     {USER_STORY_FILE_PATH}

   Update the index file at: docs/userstories/index.md to reflect the new status/filename.

   ## Rules
   - Use `git mv` (not plain mv) so git tracks any renames
   - Follow the exact Opening procedure from the guidelines
   - Update the index link to match the new filename

   ## When Done
   Report:
   1. What operation was performed (rename, status change, etc.)
   2. Confirm the index was updated
   3. Any issues encountered
   ```

   **Verification:** After the sub-agent returns, confirm the user story file is in the expected state and the index is updated.

   **Failure handling:** If the sub-agent fails, retry once with Sonnet. If still failing, perform the operation inline.

7. **Refine the user story (sub-agent).** Spawn a sub-agent to analyse and refine the user story.

   ```
   Agent(
     description: "Refine user story",
     model: "opus",
     prompt: "<constructed prompt>"
   )
   ```

   **Sub-agent prompt:**
   ```
   You are an expert Product Manager, Business Analyst, with a strong engineering background,
   and a special expertise in GDPR, sensitive information, and security.

   ## Task

   Analyse and refine the user story at: {USER_STORY_FILE_PATH}

   ## Context Files
   - User story: {USER_STORY_FILE_PATH}
   - Android guidelines: docs/guidelines/guidelines-android.md
   - Process guidelines: docs/guidelines/guidelines-process.md
   - Analytics guidelines: docs/guidelines/guidelines-analytics.md
   - Tracking plan (event dictionary): docs/analytics/tracking-plan.md

   ## Refinement Requirements

   Analyse the user story and enrich it so it is fully defined. The refined story must include:
   1. A full description of the functionality
   2. A comprehensive list of fields to be updated
   3. The structure and URLs of the necessary endpoints
   4. The files to be modified according to the architecture and best practices
   5. How to create Unit Tests
   6. How to update any relevant documentation
   7. Security potential issues and mitigations
   8. Performance potential issues and mitigations
   9. GDPR and sensitive information potential issues and mitigations
   10. An `## Analytics` section defining the events this feature must emit — their names,
       parameters, and the product question each answers — following the naming and privacy
       rules in the analytics guidelines and the existing entries in the tracking plan.
       Analytics is a product requirement of the feature that generates the data, not a
       follow-up task. If the feature genuinely warrants no new event, say so explicitly and
       give the reason. A story with no `## Analytics` section is not refined.
   11. Other non-functional requirement concerns and mitigations
   12. The steps required for the task to be considered complete

   ## Critical Constraint
   Stay at the "what" level, not the "how." Focus on requirements, acceptance criteria,
   data models, and external-facing behaviour. Do NOT prescribe architecture decisions
   (e.g. which HTTP library to use, where invalidation logic should live, specific design
   patterns) — those belong in the propose_change phase where they can be explored against
   the real codebase. Acceptance criteria should describe observable outcomes without implying
   hidden complexity that hasn't been validated against the actual cost. When listing files to
   modify, describe the intent (e.g. "persist legs locally") not the solution.

   ## Output Format
   Update the user story file:
   - Add the refined content at the TOP of the file
   - Leave the original story at the bottom, prepended with "## Original user story"
   - Downgrade original headings by one level (## becomes ###, etc.)
   - Apply proper formatting (lists, code snippets, etc.)

   ## When Done
   Report:
   1. Summary of refinements made (bullet points)
   2. Key concerns identified (security, performance, GDPR)
   3. Confirm the file was updated with new content at top and original at bottom
   4. Any assumptions made (these will be reviewed by the orchestrator)
   ```

   **Verification:** After the sub-agent returns, read the user story file and confirm it contains refined content at the top and the original story at the bottom under "## Original user story".

   **Failure handling:** If the sub-agent fails or produces incomplete output, retry once with Opus. If still failing, the orchestrator performs the refinement itself.

8. **Add a report (sub-agent).** Run `date +%s` and store the result as `{END_EPOCH}`. Then spawn a sub-agent to create or update the report.

   ```
   Agent(
     description: "Add opening report",
     model: "haiku",
     prompt: "<constructed prompt>"
   )
   ```

   **Sub-agent prompt:**
   ```
   You are generating a report section for a user story lifecycle event.

   ## Task

   Create or update the report for this user story following the report guidelines.

   ## Report Data
   - Story ID: {STORY_ID}
   - Story title: {STORY_TITLE}
   - Branch: {BRANCH_NAME}
   - Date: {ISO_DATE}
   - Refinement summary: {REFINEMENT_SUMMARY_FROM_STEP_6}
   - Command start time (epoch): {START_EPOCH}
   - Command end time (epoch): {END_EPOCH}
   - User interaction count: {INTERACTION_COUNT}

   ## Guidelines
   Read the report guidelines at: docs/guidelines/guidelines-reports.md

   ## Instructions
   The section should summarise: the user story name, the branch created, and a brief
   summary of the story refinement.

   Additionally, include a **Command Metrics** subsection at the end of the section with
   this HTML structure:

   ```html
   <h3>Command Metrics</h3>
   <table>
     <tr><th>Metric</th><th>Value</th></tr>
     <tr><td>Start time</td><td>{START_EPOCH converted to human-readable local time, formatted as YYYY-MM-DD HH:MM:SS}</td></tr>
     <tr><td>End time</td><td>{END_EPOCH converted to human-readable local time, formatted as YYYY-MM-DD HH:MM:SS}</td></tr>
     <tr><td>Duration</td><td>{computed from END_EPOCH - START_EPOCH, formatted as Xm Ys}</td></tr>
     <tr><td>User interactions</td><td>{INTERACTION_COUNT}</td></tr>
   </table>
   <p><em>Metrics are tracked by the LLM during execution. Duration includes time
   waiting for user responses. Interaction count relies on in-context tracking and
   may be approximate.</em></p>
   ```

   ## When Done
   Report:
   1. Whether the file was created or updated
   2. Confirm the section was appended correctly
   3. Any issues encountered
   ```

   **Verification:** After the sub-agent returns, confirm the report file exists and contains the new section.

   **Failure handling:** If the sub-agent fails, retry once. If still failing, the orchestrator generates the report inline.

9. **Display the summary.** Output the summary on screen so the user can see what was done: the user story opened, branch created, and key points from the refinement.

10. **Suggest a commit message.** Suggest a commit message following @docs/guidelines/guidelines-git.md.
