fastlane documentation
----

# Installation

Make sure you have the latest version of the Xcode command line tools installed:

```sh
xcode-select --install
```

For _fastlane_ installation instructions, see [Installing _fastlane_](https://docs.fastlane.tools/#installing-fastlane)

# Available Actions

## Android

### android test

```sh
[bundle exec] fastlane android test
```

Run unit tests, detekt, and lint

### android build

```sh
[bundle exec] fastlane android build
```

Build debug APK

### android beta

```sh
[bundle exec] fastlane android beta
```

Build release AAB and upload to Play Store internal track

### android deploy

```sh
[bundle exec] fastlane android deploy
```

Build release AAB and upload to Play Store production track

----

This README.md is auto-generated and will be re-generated every time [_fastlane_](https://fastlane.tools) is run.

More information about _fastlane_ can be found on [fastlane.tools](https://fastlane.tools).

The documentation of _fastlane_ can be found on [docs.fastlane.tools](https://docs.fastlane.tools).
